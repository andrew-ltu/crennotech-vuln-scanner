import { useState, useRef, useEffect } from 'react';

// --- SVG ICONS ---
const Icons = {
  Shield: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
  Layout: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" /></svg>,
  FileText: () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
  Play: () => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  ArrowLeft: () => <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>,
  Download: () => <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>,
  User: () => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>,
  Settings: () => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  LogOut: () => <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
};

// --- MOCK DATABASE ---
const mockVulnerabilities = [
  {
    id: 'VULN-8812',
    severity: 'CRITICAL',
    title: 'SQL Injection (Authentication Bypass)',
    endpoint: 'POST /api/v1/auth/login',
    category: 'Injection',
    description: 'The authentication endpoint concatenates user input directly into the SQL query without parameterization. An attacker successfully bypassed authentication using a boolean inference payload.',
    remediation: {
      language: 'C# / Entity Framework',
      code: '// VULNERABLE: var user = _db.Users.FromSqlRaw($"SELECT * FROM Users WHERE Email = \'{email}\'");\n\n// SECURE (Parameterized): \nvar user = await _db.Users.SingleOrDefaultAsync(u => u.Email == email);'
    },
    evidence: {
      req: 'POST /api/v1/auth/login HTTP/1.1\nContent-Type: application/json\n\n{\n  "email": "admin@crennotech.com\' OR 1=1--",\n  "password": "none"\n}',
      res: 'HTTP/1.1 200 OK\n\n{\n  "token": "eyJhbGciOiJIUzI1NiIs...",\n  "role": "Admin",\n  "status": "Authenticated"\n}'
    }
  },
  {
    id: 'VULN-9942',
    severity: 'HIGH',
    title: 'Insecure Direct Object Reference (IDOR)',
    endpoint: 'GET /api/v1/projects/88/settings',
    category: 'Broken Access Control',
    description: 'A lower-privileged token (Role: Staff) successfully requested and received confidential data belonging to a higher-privileged resource (Role: Admin) due to missing ownership validation at the controller level.',
    remediation: {
      language: 'C# / .NET Core',
      code: 'var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);\nvar hasAccess = await _db.UserProjects.AnyAsync(p => p.Id == id && p.OwnerId == userId);\n\nif (!hasAccess) return Forbid();'
    },
    evidence: {
      req: 'GET /api/v1/projects/88/settings HTTP/1.1\nAuthorization: Bearer [Role: Staff Token]',
      res: 'HTTP/1.1 200 OK\n\n{\n  "projectId": 88,\n  "ownerEmail": "kiran@crennotech.com",\n  "billingData": "CONFIDENTIAL_PAYLOAD_EXPOSED"\n}'
    }
  },
  {
    id: 'VULN-1044',
    severity: 'MEDIUM',
    title: 'Missing Strict-Transport-Security Header',
    endpoint: 'Global Infrastructure',
    category: 'Security Misconfiguration',
    description: 'The application fails to enforce HTTP Strict Transport Security (HSTS), leaving users vulnerable to protocol downgrade attacks and cookie hijacking on unsecure networks.',
    remediation: {
      language: 'C# / Program.cs',
      code: 'if (!app.Environment.IsDevelopment())\n{\n    app.UseHsts(); // Enforces strict transport security\n}\napp.UseHttpsRedirection();'
    },
    evidence: {
      req: 'GET / HTTP/1.1\nHost: staging.crennotech.local',
      res: 'HTTP/1.1 200 OK\nServer: Kestrel\nContent-Type: text/html\n\n// NOTE: Strict-Transport-Security header is entirely missing from response.'
    }
  }
];

export default function App() {
  const [view, setView] = useState('dashboard'); // 'dashboard' | 'detail' | 'audit' | 'users' | 'settings'
  const [selectedVuln, setSelectedVuln] = useState(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  
  // Settings State
  const [theme, setTheme] = useState('light');
  const [fontSize, setFontSize] = useState('md');

  const dropdownRef = useRef(null);
  
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) setIsProfileMenuOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleTriggerScan = () => {
    setIsScanning(true);
    setTimeout(() => setIsScanning(false), 2500);
  };

  const openVulnDetail = (vuln) => {
    setSelectedVuln(vuln);
    setView('detail');
  };

  // --- ENTERPRISE PDF GENERATION ENGINE ---
  const generateAuditPDF = () => {
    const findingRows = mockVulnerabilities.map(v => `
      <tr>
        <td><span class="badge badge-${v.severity.toLowerCase()}">${v.severity}</span></td>
        <td><strong>${v.id}</strong><br/>${v.title}</td>
        <td><code>${v.endpoint}</code></td>
        <td>Failed</td>
      </tr>
    `).join('');

    const detailedEvidenceBlocks = mockVulnerabilities.map(v => `
      <div class="evidence-section">
        <h3>Finding: ${v.id} - ${v.title}</h3>
        <p><strong>Severity:</strong> ${v.severity} | <strong>Category:</strong> ${v.category}</p>
        <p><strong>Description:</strong> ${v.description}</p>
        <div class="evidence-box">
          <div class="evidence-title">RAW HTTP CAPTURE LOGS</div>
          <p class="log-label">--- REQUEST ---</p>
          <pre class="req">${v.evidence.req}</pre>
          <p class="log-label mt-4">--- RESPONSE ---</p>
          <pre class="res">${v.evidence.res}</pre>
        </div>
        <div class="remediation-box mt-4">
          <strong>Recommended Code Fix (${v.remediation.language}):</strong>
          <pre>${v.remediation.code}</pre>
        </div>
      </div>
    `).join('');

    const reportHtml = `
      <html>
        <head>
          <title>ISO 27001 Audit Report - CrennoSec</title>
          <style>
            @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } .page-break { page-break-before: always; } }
            body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; max-width: 900px; margin: auto; }
            .cover-page { height: 90vh; display: flex; flex-direction: column; justify-content: center; border-bottom: 4px solid #0f172a; }
            h1 { font-size: 36px; color: #0f172a; margin-bottom: 10px; }
            h2 { color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; margin-top: 40px; }
            .meta-box { background: #f8fafc; padding: 20px; border-left: 4px solid #3b82f6; margin-bottom: 40px; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }
            th, td { border: 1px solid #cbd5e1; padding: 12px; text-align: left; }
            th { background-color: #f1f5f9; font-weight: 600; text-transform: uppercase; font-size: 12px; }
            .badge { padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }
            .badge-critical { background: #fee2e2; color: #b91c1c; border: 1px solid #f87171; }
            .badge-high { background: #ffedd5; color: #c2410c; border: 1px solid #fb923c; }
            .badge-medium { background: #fef9c3; color: #a16207; border: 1px solid #facc15; }
            .evidence-section { margin-top: 30px; page-break-inside: avoid; }
            .evidence-box { background: #0f172a; color: #e2e8f0; padding: 15px; border-radius: 6px; font-family: 'Courier New', Courier, monospace; font-size: 12px; }
            .evidence-title { color: #fff; font-weight: bold; border-bottom: 1px solid #334155; padding-bottom: 8px; margin-bottom: 10px; }
            .log-label { color: #94a3b8; font-size: 11px; margin: 0 0 5px 0; }
            .req { color: #60a5fa; margin: 0; white-space: pre-wrap; }
            .res { color: #f87171; margin: 0; white-space: pre-wrap; }
            .mt-4 { margin-top: 16px; }
            .remediation-box { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 15px; border-radius: 6px; font-size: 13px; }
            .remediation-box pre { margin: 10px 0 0 0; color: #166534; font-family: 'Courier New', Courier, monospace; white-space: pre-wrap;}
          </style>
        </head>
        <body>
          <div class="cover-page">
            <h1>Automated Penetration Test & Audit Report</h1>
            <p style="font-size: 20px; color: #64748b;">Crennotech Vulnerability Scanning Platform</p>
            <div class="meta-box" style="margin-top: 40px;">
              <p><strong>Execution Date:</strong> May 12, 2026</p>
              <p><strong>Scan ID:</strong> SCN-8842-A</p>
              <p><strong>Target Environment:</strong> .NET API Staging & React Frontend</p>
              <p><strong>Testing Methodology:</strong> DAST / SAST / Multi-Role Authentication Mapping</p>
            </div>
          </div>
          <div class="page-break"></div>
          <h2>1.0 Executive Summary</h2>
          <p>This document serves as formal evidence of security testing executed via the CI/CD pipeline. The automated assessment identified <strong>${mockVulnerabilities.filter(v=>v.severity === 'CRITICAL').length} Critical</strong> and <strong>${mockVulnerabilities.filter(v=>v.severity === 'HIGH').length} High</strong> severity vulnerabilities. Deployment to production is currently blocked until these issues are remediated.</p>
          
          <h2>2.0 ISO 27001 Annex A Compliance Mapping</h2>
          <table>
            <tr><th>Control Framework</th><th>Audit Requirement</th><th>Platform Status</th></tr>
            <tr><td><strong>A.8.8</strong></td><td>Management of Technical Vulnerabilities</td><td><span style="color: green; font-weight:bold;">Compliant (Automated Scans)</span></td></tr>
            <tr><td><strong>A.8.28</strong></td><td>Secure Coding Practices</td><td><span style="color: green; font-weight:bold;">Compliant (Remediation guidance provided)</span></td></tr>
            <tr><td><strong>A.5.15</strong></td><td>Access Control Validation</td><td><span style="color: red; font-weight:bold;">Failed (IDOR detected in sprint)</span></td></tr>
          </table>

          <h2>3.0 Findings Summary</h2>
          <table>
            <tr><th>Severity</th><th>Vulnerability Details</th><th>Target Scope</th><th>Pipeline Status</th></tr>
            ${findingRows}
          </table>

          <div class="page-break"></div>
          <h2>4.0 Detailed Findings & Technical Evidence</h2>
          <p>The following technical evidence was automatically captured by the CrennoSec middleware during the assessment. Raw HTTP logs are provided for non-repudiation and developer remediation.</p>
          ${detailedEvidenceBlocks}
          
          <div style="margin-top: 50px; text-align: center; color: #94a3b8; font-size: 12px; border-top: 1px solid #e2e8f0; padding-top: 20px;">
            End of Automated Report. Cryptographically verified by CrennoSec Engine.
          </div>
        </body>
      </html>
    `;
    
    const blob = new Blob([reportHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const printWindow = window.open(url, '_blank');
    printWindow.onload = () => printWindow.print();
  };

  // --- HELPER COMPONENTS ---
  const SeverityBadge = ({ sev }) => {
    const styles = {
      CRITICAL: 'bg-red-100 text-red-800 border-red-200',
      HIGH: 'bg-orange-100 text-orange-800 border-orange-200',
      MEDIUM: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      LOW: 'bg-blue-100 text-blue-800 border-blue-200'
    };
    return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold border ${styles[sev]}`}>{sev}</span>;
  };

  // --- VIEWS ---
  const DashboardView = () => (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 border-l-4 border-l-red-600">
          <p className="text-sm font-medium text-gray-500 mb-1">Critical Issues</p>
          <p className="text-3xl font-bold text-red-600">1</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 border-l-4 border-l-orange-500">
          <p className="text-sm font-medium text-gray-500 mb-1">High Issues</p>
          <p className="text-3xl font-bold text-orange-600">1</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 border-l-4 border-l-yellow-400">
          <p className="text-sm font-medium text-gray-500 mb-1">Medium Issues</p>
          <p className="text-3xl font-bold text-yellow-600">1</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 border-l-4 border-l-green-500">
          <p className="text-sm font-medium text-gray-500 mb-1">Code Quality Score</p>
          <p className="text-3xl font-bold text-green-600">72%</p>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
          <h2 className="font-semibold text-gray-800">Identified Vulnerabilities (Action Required)</h2>
          <button onClick={generateAuditPDF} className="text-sm text-blue-600 font-medium hover:underline flex items-center"><Icons.Download /> Generate Executive Report</button>
        </div>
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500 font-medium border-b border-gray-100">
            <tr><th className="px-6 py-3">Severity</th><th className="px-6 py-3">Vulnerability</th><th className="px-6 py-3">Target Endpoint</th><th className="px-6 py-3">Action</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {mockVulnerabilities.map(vuln => (
              <tr key={vuln.id} className="hover:bg-blue-50/50 transition cursor-pointer group" onClick={() => openVulnDetail(vuln)}>
                <td className="px-6 py-4"><SeverityBadge sev={vuln.severity} /></td>
                <td className="px-6 py-4 font-medium text-gray-900 group-hover:text-blue-700">{vuln.title}</td>
                <td className="px-6 py-4 text-gray-500 font-mono text-xs">{vuln.endpoint}</td>
                <td className="px-6 py-4"><button className="text-blue-600 font-medium group-hover:underline flex items-center">Review Evidence &rarr;</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const DetailView = () => {
    if (!selectedVuln) return null;
    return (
      <div className="p-8 max-w-7xl mx-auto animate-in fade-in slide-in-from-right-4 duration-300">
        <button onClick={() => setView('dashboard')} className="flex items-center text-sm font-medium text-gray-500 hover:text-gray-900 mb-6 transition">
          <Icons.ArrowLeft /> Back to Dashboard
        </button>
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-8">
          <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-start">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <SeverityBadge sev={selectedVuln.severity} />
                <span className="text-sm font-mono text-gray-400">{selectedVuln.id}</span>
                <span className="text-sm font-medium bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{selectedVuln.category}</span>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">{selectedVuln.title}</h1>
              <p className="text-gray-500 mt-1 font-mono text-sm">Target: {selectedVuln.endpoint}</p>
            </div>
            <button className="px-4 py-2 bg-blue-600 text-white font-medium text-sm rounded-lg hover:bg-blue-700 transition shadow-sm">
              Create Jira Ticket
            </button>
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-2 divide-y xl:divide-y-0 xl:divide-x divide-gray-100">
            <div className="p-8 bg-gray-50/50">
              <h3 className="font-bold text-gray-900 mb-2">Issue Description</h3>
              <p className="text-gray-600 text-sm leading-relaxed mb-6">{selectedVuln.description}</p>
              
              <h3 className="font-bold text-gray-900 mb-2 border-t border-gray-200 pt-6">Automated Remediation ({selectedVuln.remediation.language})</h3>
              <div className="bg-slate-900 rounded-lg p-4 font-mono text-sm overflow-x-auto text-slate-300 shadow-inner">
                <pre>{selectedVuln.remediation.code}</pre>
              </div>
            </div>
            <div className="p-8 bg-white">
               <h3 className="font-bold text-gray-900 mb-4 flex justify-between items-center">
                 Raw HTTP Audit Evidence
                 <span className="text-xs font-normal text-gray-400 bg-gray-100 px-2 py-1 rounded">Captured via DAST</span>
               </h3>
               <div className="bg-[#1e1e1e] rounded-lg p-5 font-mono text-xs overflow-x-auto text-gray-300 shadow-inner">
                 <p className="text-gray-500 mb-2">--- RAW REQUEST ---</p>
                 <pre className="text-blue-300 whitespace-pre-wrap">{selectedVuln.evidence.req}</pre>
                 
                 <p className="text-gray-500 mt-6 mb-2">--- RAW RESPONSE ---</p>
                 <pre className="text-red-300 font-bold whitespace-pre-wrap">{selectedVuln.evidence.res}</pre>
               </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const AuditReportsView = () => (
    <div className="p-8 max-w-7xl mx-auto animate-in fade-in duration-500">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Compliance Audit Reports</h1>
          <p className="text-gray-500 text-sm">Exportable ISO 27001 evidence logs generated from CI/CD pipeline scans.</p>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500 font-medium border-b border-gray-100">
            <tr><th className="px-6 py-4">Execution Date</th><th className="px-6 py-4">Scan ID</th><th className="px-6 py-4">Target Scope</th><th className="px-6 py-4">Status</th><th className="px-6 py-4 text-right">Evidence Artifacts</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            <tr className="hover:bg-gray-50 transition">
              <td className="px-6 py-4 font-medium">May 12, 2026 - 10:12 AM</td>
              <td className="px-6 py-4 font-mono text-xs text-gray-500">SCN-8842-A</td>
              <td className="px-6 py-4">.NET API Staging</td>
              <td className="px-6 py-4"><span className="px-2.5 py-1 rounded-md text-xs font-medium bg-red-50 text-red-700 border border-red-200">Failed (Blocked)</span></td>
              <td className="px-6 py-4 text-right">
                <button onClick={generateAuditPDF} className="text-blue-600 font-medium hover:underline text-sm mr-4 flex items-center justify-end w-full"><Icons.Download /> PDF Report</button>
              </td>
            </tr>
            <tr className="hover:bg-gray-50 transition">
              <td className="px-6 py-4 font-medium">May 11, 2026 - 14:30 PM</td>
              <td className="px-6 py-4 font-mono text-xs text-gray-500">SCN-8841-B</td>
              <td className="px-6 py-4">React Frontend Prod</td>
              <td className="px-6 py-4"><span className="px-2.5 py-1 rounded-md text-xs font-medium bg-green-50 text-green-700 border border-green-200">Passed</span></td>
              <td className="px-6 py-4 text-right text-gray-400 text-sm">Historical (Archived)</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );

  const UserManagementView = () => (
    <div className="p-8 max-w-7xl mx-auto animate-in fade-in duration-500">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">User Management & Access Control</h1>
      <p className="text-gray-500 text-sm mb-8">Manage team members, roles, and platform permissions.</p>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
          <h2 className="font-semibold text-gray-800">Active Users</h2>
          <button className="bg-slate-900 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-slate-800">+ Invite User</button>
        </div>
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500 font-medium border-b border-gray-100">
            <tr><th className="px-6 py-3">User Name</th><th className="px-6 py-3">Role</th><th className="px-6 py-3">Access Level</th><th className="px-6 py-3">Status</th></tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            <tr className="hover:bg-gray-50">
              <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">KV</div> Kiran Vilasagaram</td>
              <td className="px-6 py-4 text-gray-600">Administrator</td>
              <td className="px-6 py-4 text-gray-600">Full Access</td>
              <td className="px-6 py-4"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">Active</span></td>
            </tr>
            <tr className="hover:bg-gray-50">
              <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center font-bold text-xs">A</div> Alex (Developer)</td>
              <td className="px-6 py-4 text-gray-600">Engineer</td>
              <td className="px-6 py-4 text-gray-600">Read / Write</td>
              <td className="px-6 py-4"><span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs font-medium">Active</span></td>
            </tr>
            <tr className="hover:bg-gray-50">
              <td className="px-6 py-4 font-medium text-gray-900 flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">IA</div> ISO Auditor</td>
              <td className="px-6 py-4 text-gray-600">Compliance</td>
              <td className="px-6 py-4 text-gray-600">Read-Only</td>
              <td className="px-6 py-4"><span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium">Provisioned</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );

  const SettingsView = () => (
    <div className="p-8 max-w-3xl mx-auto animate-in fade-in duration-500">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Platform Settings</h1>
      <p className="text-gray-500 text-sm mb-8">Customize your application preferences and UI appearance.</p>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4 border-b pb-2">Appearance</h3>
          <div className="flex items-center justify-between py-2">
            <div>
              <p className="font-medium text-gray-800">Interface Theme</p>
              <p className="text-sm text-gray-500">Select light or dark mode.</p>
            </div>
            <select value={theme} onChange={(e) => setTheme(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5">
              <option value="light">Light Mode</option>
              <option value="dark">Dark Mode (Coming Soon)</option>
            </select>
          </div>
          <div className="flex items-center justify-between py-2 mt-4">
            <div>
              <p className="font-medium text-gray-800">Font Size</p>
              <p className="text-sm text-gray-500">Adjust the global text size.</p>
            </div>
            <select value={fontSize} onChange={(e) => setFontSize(e.target.value)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 p-2.5">
              <option value="sm">Small</option>
              <option value="md">Medium</option>
              <option value="lg">Large</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );

  // --- LAYOUT SHELL ---
  return (
    <div className={`flex h-screen bg-gray-50 font-sans selection:bg-blue-200 ${fontSize === 'lg' ? 'text-lg' : fontSize === 'sm' ? 'text-sm' : 'text-base'}`}>
      {/* Sidebar */}
      <div className="w-64 bg-slate-900 text-slate-300 flex flex-col min-h-screen">
        <div className="h-16 flex items-center px-6 border-b border-slate-800">
          <div className="text-blue-500 mr-2"><Icons.Shield /></div>
          <span className="text-white font-bold text-lg tracking-wide">Crenno<span className="text-blue-500">Sec</span></span>
        </div>
        <nav className="flex-1 py-6 px-4 space-y-2">
          <button onClick={() => setView('dashboard')} className={`w-full flex items-center px-4 py-2.5 rounded-lg font-medium transition ${view === 'dashboard' || view === 'detail' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
            <Icons.Layout /> <span className="ml-3">Dashboard</span>
          </button>
          <button onClick={() => setView('audit')} className={`w-full flex items-center px-4 py-2.5 rounded-lg font-medium transition ${view === 'audit' ? 'bg-blue-600/10 text-blue-400' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
            <Icons.FileText /> <span className="ml-3">Audit Reports</span>
          </button>
        </nav>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 relative z-50">
          <div className="text-sm text-gray-500 font-medium">Crennotech / <span className="text-gray-900 capitalize">{view === 'detail' ? 'Investigate' : view.replace('-', ' ')}</span></div>
          <div className="flex items-center gap-4">
            <button onClick={handleTriggerScan} disabled={isScanning} className={`flex items-center px-4 py-2 rounded-md font-medium text-sm transition ${isScanning ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-slate-800 shadow-sm'}`}>
              {isScanning ? <span className="animate-pulse">Running Scan...</span> : <><Icons.Play /> Trigger Pipeline</>}
            </button>
            <div className="relative" ref={dropdownRef}>
              <button onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)} className="h-9 w-9 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center font-bold text-sm border border-blue-200 hover:bg-blue-200 transition">KV</button>
              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-gray-100 py-1">
                  <div className="px-4 py-3 border-b border-gray-100 bg-gray-50"><p className="text-sm font-semibold text-gray-900">Kiran Vilasagaram</p><p className="text-xs text-gray-500">Administrator</p></div>
                  <button onClick={() => { setView('users'); setIsProfileMenuOpen(false); }} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center"><Icons.User /> User Management</button>
                  <button onClick={() => { setView('settings'); setIsProfileMenuOpen(false); }} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 flex items-center"><Icons.Settings /> Platform Settings</button>
                  <div className="border-t border-gray-100 my-1"></div>
                  <button onClick={() => setIsProfileMenuOpen(false)} className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center"><Icons.LogOut /> Sign out</button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* View Router */}
        <main className="flex-1 overflow-y-auto">
          {view === 'dashboard' && <DashboardView />}
          {view === 'detail' && <DetailView />}
          {view === 'audit' && <AuditReportsView />}
          {view === 'users' && <UserManagementView />}
          {view === 'settings' && <SettingsView />}
        </main>
      </div>
    </div>
  );
}