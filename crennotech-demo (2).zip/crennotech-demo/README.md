**CrennoSec UI: Operational User Manual**





This manual provides step-by-step instructions for launching the CrennoSec React mockup on your local machine and operating its interactive features during a demonstration or testing session.

Part 1: Running the UI (Startup Guide)

Before you can use the dashboard, you must launch the local Vite development server.

Prerequisites: You must have Node.js installed on your computer.

Step 1: Open the Project

Unzip the crennosec-dashboard folder provided by the development team.

Open your preferred Terminal (Command Prompt on Windows, Terminal on Mac).

Navigate into the project folder using the cd command:

Bash: cd path/to/crennosec-dashboard

Step 2: Install Dependencies

If this is your first time running the application, you must download the necessary React and Tailwind CSS packages.

Run the following command:

Bash: npm install

Wait a few moments for the installation to complete. You will see a new node\_modules folder appear in your project directory.

Step 3: Start the Server

Run the development server command:

Bash: npm run dev

The terminal will output a local web address. Open your Google Chrome or Microsoft Edge browser and navigate to: http://localhost:5173









Part 2: Using the UI (Feature Walkthrough)

Once the application is running in your browser, you can interact with the following features.

1\. The Main Dashboard

When the app loads, you are greeted by the Command Center.

Metrics Ribbon: Across the top, review the colored cards (Critical Issues, High Issues, Medium Issues, Code Quality Score).

Actionable Findings Table: Below the metrics, view the list of simulated vulnerabilities that currently require developer attention.

2\. Investigating a Vulnerability (Evidence Collection)

In the main dashboard table, hover over the Insecure Direct Object Reference (IDOR) row.

Click the blue Review Evidence → text.

You will instantly be routed to the Investigation View.

Left Side: Read the issue description and review the automated C# remediation code.

Right Side: Review the black terminal window containing the raw HTTP request and response logs. This is your simulated ISO 27001 audit evidence.

Click Back to Dashboard (top left) to return to the main screen.

3\. Generating the ISO 27001 PDF Report

The platform can dynamically generate a formal, multi-page audit report for compliance purposes.

From the main dashboard, click Generate Executive Report (located just above the vulnerabilities table).

A new browser tab will open automatically.

The platform will render a formatted HTML report mapping the findings to ISO 27001 Annex A controls, and immediately open your browser's Print dialogue.

Set the print destination to "Save as PDF" to keep a copy of the report, or simply click Cancel and close the tab to return to the dashboard.

4\. Accessing Historical Reports

Look at the dark sidebar on the left side of the screen.

Click the Audit Reports tab.

Here you can view a simulated history of past CI/CD pipeline executions, tracking which scans Failed (Blocked) and which Passed.

5\. User Profile \& Platform Settings

In the top right corner of the header, click the blue KV profile icon. A dropdown menu will appear.

Click User Management to view the simulated Role-Based Access Control (RBAC) table, showing the permissions of Administrators, Engineers, and ISO Auditors.

Click the KV profile icon again and select Platform Settings.

In the Settings view, locate the Font Size dropdown.

Change the selection from Medium to Large. The entire application interface will dynamically scale up, demonstrating the platform's responsive accessibility features.

Part 3: Troubleshooting

Terminal says port 5173 is in use: Another application is using the default port. Vite will automatically try the next available port (e.g., 5174). Check the terminal output for the correct URL.

The screen is blank/white: Check your terminal window. If there is a syntax error in App.jsx, the terminal will display the exact line number causing the crash.

Styles are missing (plain text only): Ensure you successfully ran npm install and that your src/index.css file contains the @import "tailwindcss"; directive.







